import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class XYMouseListener implements MouseListener {

    public void mouseClicked(MouseEvent e){
        System.out.println("X=" + e.getX());
        System.out.println("X=" + e.getY());

    }
     public void mousePressed(MouseEvent e){
        
    }

     public void mouseReleased(MouseEvent e){
        
    }
    public void mouseExited(MouseEvent e){
        
    }
    public void mouseEntered(MouseEvent e){
        
    }


    
}
