
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class TelaPrincipal extends JFrame {


    private JButton botao1,botao2,botao3,botao4,botao5;


    public TelaPrincipal(){
        this.setTitle("tela swing");
        this.setSize(600,600);
        //LayoutManager layout = new FlowLayout(FlowLayout.LEFT, 20, 50);
       //layout = new GridLayout(2,3);
        //.setLayout(layout);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        botao1 = new JButton("botao 1");
        botao2 = new JButton("botao 2");
        botao3 = new JButton("botao 3");
        botao4 = new JButton("botao 4");
        botao5 = new JButton("botao 5");
        this.setVisible(true);

        this.add(botao1, BorderLayout.CENTER);
        this.add(criarPainelBotoes(), BorderLayout.NORTH);
        this.add(botao3, BorderLayout.SOUTH);
        this.add(botao4, BorderLayout.WEST);
        this.add(botao5, BorderLayout.EAST);
        botao5.addMouseListener(new XYMouseListener() {
            
        });
    }

private JPanel criarPainelBotoes(){
    JPanel painelDeBotoes = new JPanel();
    botao2 = new JButton ("botao2");
    painelDeBotoes.add(botao2);
    return painelDeBotoes;
}
    public static void main (String[] args){
        TelaPrincipal tela = new TelaPrincipal();
    }

    
}